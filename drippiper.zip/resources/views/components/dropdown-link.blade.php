<a {{ $attributes->merge(['class' => 'block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-600 hover:text-white']) }}>{{ $slot }}</a>
