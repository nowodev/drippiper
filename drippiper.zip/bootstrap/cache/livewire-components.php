<?php return array (
  'cart' => 'App\\Http\\Livewire\\Cart',
  'product' => 'App\\Http\\Livewire\\Product',
  'product-form' => 'App\\Http\\Livewire\\ProductForm',
);