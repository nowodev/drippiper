<div x-data="{ colour: <?php if ((object) ($attributes->wire('model')) instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e($attributes->wire('model')->value()); ?>')<?php echo e($attributes->wire('model')->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e($attributes->wire('model')); ?>')<?php endif; ?> }" x-init="
        picker = new Picker($refs.button);
        picker.onDone = rawColor => {
            colour = rawColor.hex;
            $dispatch('input', colour)
        }
    " wire:ignore <?php echo e($attributes); ?>>

    <button x-ref="button" class="w-full h-full">
        <span class="block mt-1 text-left w-full rounded-md form-input focus:border-indigo-600"
            x-text="colour" :style="`background: ${colour}`">
        </span>
    </button>
</div><?php /**PATH /media/favour/01D53CC3C9E86E80/Projects/BitsandNibble/drippiper/resources/views/components/color.blade.php ENDPATH**/ ?>