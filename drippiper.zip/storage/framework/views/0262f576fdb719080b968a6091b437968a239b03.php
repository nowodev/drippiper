<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'py-2 px-4 text-center bg-indigo-600 rounded-md text-white text-sm hover:bg-indigo-500'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /media/favour/01D53CC3C9E86E80/Projects/BitsandNibble/drippiper/resources/views/components/button.blade.php ENDPATH**/ ?>