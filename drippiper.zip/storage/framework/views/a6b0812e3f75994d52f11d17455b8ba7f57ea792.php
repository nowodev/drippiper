<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="items-center gap-x-3">
            <button onclick="history.back(-1)">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"
                    class="w-5 h-5">
                    <path fill-rule="evenodd"
                        d="M7.793 2.232a.75.75 0 01-.025 1.06L3.622 7.25h10.003a5.375 5.375 0 010 10.75H10.75a.75.75 0 010-1.5h2.875a3.875 3.875 0 000-7.75H3.622l4.146 3.957a.75.75 0 01-1.036 1.085l-5.5-5.25a.75.75 0 010-1.085l5.5-5.25a.75.75 0 011.06.025z"
                        clip-rule="evenodd" />
                </svg>
            </button>

            <?php echo e($order->order_no); ?>

        </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white">
        <div class="px-4 py-16 mx-auto max-w-7xl sm:px-6 sm:py-24 lg:px-8">
            <h1 class="text-3xl font-extrabold tracking-tight text-gray-900">Order Details</h1>

            <div class="pb-5 mt-2 text-sm border-b border-gray-200 sm:flex sm:justify-between">
                <dl class="flex">
                    <dt class="text-gray-500">Order number&nbsp;</dt>
                    <dd class="font-medium text-gray-900"><?php echo e($order->order_no); ?></dd>
                    <dt>
                        <span class="sr-only">Date</span>
                        <span class="mx-2 text-gray-400" aria-hidden="true">&middot;</span>
                    </dt>
                    <dd class="font-medium text-gray-900">
                        <?php echo e($order->created_at->format('F d, Y')); ?>

                    </dd>
                </dl>
                
            </div>

            <div class="mt-8">
                <h2 class="sr-only">Products purchased</h2>

                <div class="space-y-24">
                    <?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div
                        class="grid grid-cols-1 text-sm sm:grid-rows-1 sm:grid-cols-12 sm:gap-x-6 md:gap-x-8 lg:gap-x-8">
                        <div class="sm:col-span-4 md:col-span-5 md:row-end-2 md:row-span-2">
                            <div
                                class="overflow-hidden rounded-lg aspect-w-1 aspect-h-1 bg-gray-50">
                                <img src="<?php echo e($item->product->thumbnail); ?>" alt=""
                                    class="object-cover object-center">
                            </div>
                        </div>
                        <div class="mt-6 sm:col-span-7 sm:mt-0 md:row-end-1">
                            <h3 class="flex justify-between text-lg font-medium text-gray-900">
                                <a href="<?php echo e(route('admin.products.show', $item->product_id)); ?>">
                                    <?php echo e($item->product->name); ?>

                                </a>

                                <p class="font-medium text-gray-900">₦<?php echo e($item->total); ?></p>
                            </h3>
                            <p class="flex items-center mt-1 font-medium text-gray-900 gap-x-3">
                                Colour:
                                <label
                                    class="-m-0.5 relative p-0.5 rounded-full flex focus:outline-none">
                                    <span aria-hidden="true"
                                        style="background: <?php echo e($item->stock->colour); ?>"
                                        class="h-8 w-8 border border-black border-opacity-10 rounded-full"></span>
                                </label>
                            </p>
                            <p class="mt-1 font-medium text-gray-900">Size: <?php echo e($item->stock->size); ?>

                            </p>
                            <p class="mt-1 font-medium text-gray-900">Qty:
                                <?php echo e($item->quantity); ?>

                            </p>
                            <p class="mt-3 text-gray-500">
                                <?php echo e($item->product->description); ?>

                            </p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="sm:col-span-12 md:col-span-7">
                        <p class="mt-6 font-medium text-gray-900 md:mt-10">Processing on
                            <?php echo e($order->created_at->format('F d, Y')); ?>

                        </p>
                        <div class="mt-6">
                            <div class="overflow-hidden bg-gray-200 rounded-full">
                                <div class="h-2 bg-indigo-600 rounded-full"
                                    style="width: calc((1 * <?php echo e($progress_no); ?> + 1) / 8 * 100%)">
                                </div>
                            </div>
                            <div class="hidden grid-cols-4 mt-6 font-medium text-gray-600 sm:grid">
                                <div class="">Order placed</div>
                                <div class="text-center">Processing</div>
                                <div class="text-center">Shipped</div>
                                <div class="text-right">Delivered</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Billing -->
        <div class="mt-24">
            <h2 class="sr-only">Billing Summary</h2>

            <div
                class="px-6 py-6 rounded-lg bg-gray-50 lg:px-0 lg:py-8 lg:grid lg:grid-cols-12 lg:gap-x-8">
                <dl
                    class="grid grid-cols-1 gap-6 text-sm sm:grid-cols-2 md:gap-x-8 lg:pl-8 lg:col-span-5">
                    <div>
                        <dt class="font-medium text-gray-900">Shipping address</dt>
                        <dd class="mt-3 text-gray-500">
                            <span class="block"><?php echo e($order->user->name); ?></span>
                            <span class="block"><?php echo e($order->user->phone); ?></span>
                            <span class="block"><?php echo e($order->user->email); ?></span>
                            <span class="block"><?php echo e($order->user->address); ?></span>
                            <span
                                class="block"><?php echo e($order->user->city . ', ' . $order->user->state); ?></span>
                        </dd>
                    </div>
                </dl>

                <dl class="mt-8 text-sm divide-y divide-gray-200 lg:mt-0 lg:pr-8 lg:col-span-7">
                    <div class="flex items-center justify-between pb-4">
                        <dt class="text-gray-600">Subtotal</dt>
                        <dd class="font-medium text-gray-900">₦<?php echo e($order->order_total - 2500); ?>

                        </dd>
                    </div>
                    <div class="flex items-center justify-between py-4">
                        <dt class="text-gray-600">Shipping</dt>
                        <dd class="font-medium text-gray-900">₦2500</dd>
                    </div>
                    <div class="flex items-center justify-between pt-4">
                        <dt class="font-medium text-gray-900">Order total</dt>
                        <dd class="font-medium text-indigo-600">₦<?php echo e($order->order_total); ?></dd>
                    </div>
                </dl>
            </div>
        </div>
    </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH /media/favour/01D53CC3C9E86E80/Projects/BitsandNibble/drippiper/resources/views/admin/orders/show.blade.php ENDPATH**/ ?>