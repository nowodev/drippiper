<div x-data="{ colour: <?php if ((object) ('colour') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('colour'->value()); ?>')<?php echo e('colour'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('colour'); ?>')<?php endif; ?>, size: <?php if ((object) ('size') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('size'->value()); ?>')<?php echo e('size'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('size'); ?>')<?php endif; ?>, quantity: <?php if ((object) ('quantity') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('quantity'->value()); ?>')<?php echo e('quantity'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('quantity'); ?>')<?php endif; ?> }"
    class="bg-white">
    <div class="pt-6 pb-16 sm:pb-24">
        <nav aria-label="Breadcrumb" class="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
            <ol role="list" class="flex items-center space-x-4">
                <li>
                    <div class="flex items-center">
                        <a href="#" class="mr-4 text-sm font-medium text-gray-900">
                            <?php echo e($product?->category?->name); ?> </a>
                        <svg viewBox="0 0 6 20" xmlns="http://www.w3.org/2000/svg"
                            aria-hidden="true" class="w-auto h-5 text-gray-300">
                            <path d="M4.878 4.34H3.551L.27 16.532h1.327l3.281-12.19z"
                                fill="currentColor" />
                        </svg>
                    </div>
                </li>

                <li class="text-sm">
                    <p class="font-medium text-gray-500 hover:text-gray-600">
                        <?php echo e($product->name); ?>

                    </p>
                </li>
            </ol>
        </nav>
        <div class="max-w-2xl px-4 mx-auto mt-8 sm:px-6 lg:max-w-7xl lg:px-8">
            <div class="lg:grid lg:grid-cols-12 lg:auto-rows-min lg:gap-x-8">
                <div class="lg:col-start-8 lg:col-span-5">
                    <div class="flex justify-between">
                        <h1 class="text-xl font-medium text-gray-900"><?php echo e($product->name); ?></h1>
                        <p class="text-xl font-medium text-gray-900">₦<?php echo e($product->price); ?></p>
                    </div>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.errors','data' => ['class' => 'mt-8']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>

                <!-- Image gallery -->
                <div class="mt-8 lg:mt-0 lg:col-start-1 lg:col-span-7 lg:row-start-1 lg:row-span-3">
                    <h2 class="sr-only">Images</h2>

                    <div class="grid grid-cols-1 lg:grid-cols-2 lg:gridrows-3 lg:gap-8">
                        <img src="<?php echo e($product->thumbnail); ?>" alt=""
                            class="rounded-lg lg:col-span-2 lg:row-span-2">

                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/' . $image->name)); ?>" alt=""
                            class="hidden rounded-lg lg:block h-full">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="mt-8 lg:col-span-5">
                    <form method="POST" action="<?php echo e(route('customer.cart.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="colour" value="<?php echo e($colour); ?>">
                        <input type="hidden" name="size" value="<?php echo e($size); ?>">
                        <input type="hidden" name="quantity" value="<?php echo e($quantity); ?>">

                        <!-- Color picker -->
                        <div>
                            <h2 class="text-sm font-medium text-gray-900">Color</h2>

                            <fieldset class="mt-2">
                                <legend class="sr-only">Choose a color</legend>
                                <div class="flex items-center space-x-3">
                                    <!--
                      Active and Checked: "ring ring-offset-1"
                      Not Active and Checked: "ring-2"
                    -->
                                    <?php $__currentLoopData = $product->stocks->unique('colour'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label @click="$wire.set('colour', <?php echo \Illuminate\Support\Js::from($stock->colour)->toHtml() ?>)"
                                        :class="colour == <?php echo \Illuminate\Support\Js::from($stock->colour)->toHtml() ?> ? 'ring ring-offset-1' : ''"
                                        class="-m-0.5 relative p-0.5 rounded-full flex items-center justify-center cursor-pointer focus:outline-none ring-gray-900">
                                        <span aria-hidden="true"
                                            class="h-8 w-8 border border-black border-opacity-10 rounded-full"
                                            style="background: <?php echo e($stock->colour); ?>;"></span>
                                    </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </fieldset>
                        </div>

                        <!-- Size picker -->
                        <div class="mt-8">
                            <?php if(!is_null($colour)): ?>

                            <div class="flex items-center justify-between">
                                <h2 class="text-sm font-medium text-gray-900">Size</h2>
                            </div>

                            <fieldset class="mt-2">
                                <legend class="sr-only">Choose a size</legend>
                                <div class="grid grid-cols-3 gap-3 sm:grid-cols-6">
                                    <!--
                      In Stock: "cursor-pointer", Out of Stock: "opacity-25 cursor-not-allowed"
                      Active: "ring-2 ring-offset-2 ring-indigo-500"
                      Checked: "bg-indigo-600 border-transparent text-white hover:bg-indigo-700", Not Checked: "bg-white border-gray-200 text-gray-900 hover:bg-gray-50"
                    -->
                                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label @click="$wire.set('size', <?php echo \Illuminate\Support\Js::from($item->size)->toHtml() ?>)"
                                        :class="size == <?php echo \Illuminate\Support\Js::from($item->size)->toHtml() ?> ? 'ring-2 ring-offset-2 ring-indigo-500 bg-indigo-600 border-transparent text-white hover:bg-indigo-700' : 'bg-white border-gray-200 text-gray-900 hover:bg-gray-50'"
                                        class="flex items-center justify-center p-3 text-sm font-medium uppercase border rounded-md cursor-pointer sm:flex-1 focus:outline-none">
                                        <p><?php echo e($item->size); ?></p>
                                    </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </fieldset>
                            <?php endif; ?>
                        </div>

                        <!-- Size picker -->
                        <div class="mt-8">
                            <?php if(!is_null($size)): ?>

                            <div class="flex items-center justify-between">
                                <h2 class="text-sm font-medium text-gray-900">Quantity</h2>
                            </div>

                            <fieldset class="mt-2">
                                <legend class="sr-only">Select quantity</legend>
                                <div class="grid grid-cols-3 gap-3 sm:grid-cols-6">
                                    <!--
                      In Stock: "cursor-pointer", Out of Stock: "opacity-25 cursor-not-allowed"
                      Active: "ring-2 ring-offset-2 ring-indigo-500"
                      Checked: "bg-indigo-600 border-transparent text-white hover:bg-indigo-700", Not Checked: "bg-white border-gray-200 text-gray-900 hover:bg-gray-50"
                    -->
                                    <?php for($qty = 1; $qty <= $totalQuantity; $qty++): ?> <label
                                        @click="$wire.set('quantity', <?php echo \Illuminate\Support\Js::from($qty)->toHtml() ?>)"
                                        :class="quantity == <?php echo \Illuminate\Support\Js::from($qty)->toHtml() ?> ? 'ring-2 ring-offset-2 ring-indigo-500 bg-indigo-600 border-transparent text-white hover:bg-indigo-700' : 'bg-white border-gray-200 text-gray-900 hover:bg-gray-50'"
                                        class="flex items-center justify-center p-1 text-sm font-medium uppercase border rounded-md cursor-pointer sm:flex-1 focus:outline-none">
                                        <p><?php echo e($qty); ?></p>
                                        </label>
                                        <?php endfor; ?>
                                </div>
                            </fieldset>
                            <?php endif; ?>
                        </div>

                        <button type="submit"
                            class="flex items-center justify-center w-full px-8 py-3 mt-8 text-base font-medium text-white bg-indigo-600 border border-transparent rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Add
                            to cart</button>
                    </form>

                    <!-- Product details -->
                    <div class="mt-10">
                        <h2 class="text-sm font-medium text-gray-900">Description</h2>

                        <div class="mt-4 prose-sm prose text-gray-500">
                            <p>The Basic tee is an honest new take on a classic. The tee uses
                                super soft, pre-shrunk cotton for true comfort and a dependable
                                fit. They are hand cut and sewn locally, with a special dye
                                technique that gives each tee it's own look.</p>
                            <p>Looking to stock your closet? The Basic tee also comes in a
                                3-pack or 5-pack at a bundle discount.</p>
                        </div>
                    </div>

                    <!-- Policies -->
                    <section aria-labelledby="policies-heading" class="mt-10">
                        <h2 id="policies-heading" class="sr-only">Our Policies</h2>

                        <dl
                            class="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                            <div
                                class="p-6 text-center border border-gray-200 rounded-lg bg-gray-50">
                                <dt>
                                    <!-- Heroicon name: outline/globe -->
                                    <svg class="flex-shrink-0 w-6 h-6 mx-auto text-gray-400"
                                        xmlns="http://www.w3.org/2000/svg" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor"
                                        aria-hidden="true">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="2"
                                            d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    <span class="mt-4 text-sm font-medium text-gray-900">
                                        Fast delivery </span>
                                </dt>
                                <dd class="mt-1 text-sm text-gray-500">Get your order in 2 days
                                </dd>
                            </div>
                        </dl>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /media/favour/01D53CC3C9E86E80/Projects/BitsandNibble/piperwears/resources/views/livewire/product.blade.php ENDPATH**/ ?>