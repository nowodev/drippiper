<?php $__env->startComponent($view, $params); ?>
    <?php $__env->slot($slotOrSection); ?>
        <?php echo $manager->initialDehydrate()->toInitialResponse()->effects['html']; ?>

    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /media/favour/01D53CC3C9E86E80/Projects/BitsandNibble/piperwears/vendor/livewire/livewire/src/Macros/livewire-view-component.blade.php ENDPATH**/ ?>